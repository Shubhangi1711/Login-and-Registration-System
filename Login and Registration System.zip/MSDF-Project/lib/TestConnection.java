import java.sql.Connection;
import java.sql.DriverManager;

public class TestConnection {

    public static void main(String[] args) {

        try {
            // Step 1: Get connection
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/testdb",
                "root",
                "Shub@123"
            );

            // Step 2: Check connection
            System.out.println("JDBC Connected Successfully!");

            // Step 3: Close connection
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
