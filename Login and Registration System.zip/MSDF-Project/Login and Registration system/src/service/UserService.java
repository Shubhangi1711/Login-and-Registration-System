package service;

import dao.UserDAO;

public class UserService {

    UserDAO dao = new UserDAO();
    private int attempts = 3;

    // ===== Password Validation =====
    private boolean isValidPassword(String password) {
        if (password.length() < 6) return false;

        boolean hasDigit = false;
        for (char c : password.toCharArray()) {
            if (Character.isDigit(c)) {
                hasDigit = true;
                break;
            }
        }
        return hasDigit;
    }

    // ===== REGISTER =====
    public void registerUser(String username, String password,
                             String securityQuestion, String securityAnswer) {

        if (!isValidPassword(password)) {
            System.out.println("Password must be at least 6 characters and contain a digit.");
            return;
        }

        if (dao.register(username, password, securityQuestion, securityAnswer)) {
            System.out.println("Registration successful!");
        }
    }

    // ===== LOGIN =====
    public void loginUser(String username, String password) {

        if (attempts == 0) {
            System.out.println("Account locked due to multiple failed attempts.");
            return;
        }

        if (dao.login(username, password)) {
            System.out.println("Login successful!");
            attempts = 3;
        } else {
            attempts--;
            System.out.println("Invalid username or password.");
            System.out.println("Attempts left: " + attempts);
        }
    }

    // ===== FORGOT PASSWORD =====
    public void forgotPassword(String username, String answer, String newPassword) {

        if (!isValidPassword(newPassword)) {
            System.out.println("New password is too weak.");
            return;
        }

        if (dao.resetPassword(username, answer, newPassword)) {
            System.out.println("Password updated successfully!");
        } else {
            System.out.println("Security answer incorrect.");
        }
    }

    // ===== DELETE ACCOUNT =====
    public void deleteAccount(String username) {
        if (dao.deleteUser(username)) {
            System.out.println("Account deleted successfully.");
        } else {
            System.out.println("Account deletion failed.");
        }
    }
}
