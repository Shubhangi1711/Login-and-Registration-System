package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDAO {

    // ===== REGISTER =====
    public boolean register(String username, String password,
                            String securityQuestion, String securityAnswer) {

        String sql = "INSERT INTO users (username, password, security_question, security_answer) VALUES (?, ?, ?, ?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, username);
            ps.setString(2, password);
            ps.setString(3, securityQuestion);
            ps.setString(4, securityAnswer);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            System.out.println("Username already exists!");
        }
        return false;
    }

    // ===== LOGIN =====
    public boolean login(String username, String password) {

        String sql = "SELECT * FROM users WHERE username=? AND password=?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();
            return rs.next();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // ===== RESET PASSWORD =====
    public boolean resetPassword(String username, String answer, String newPassword) {

        String sql = "UPDATE users SET password=? WHERE username=? AND security_answer=?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, newPassword);
            ps.setString(2, username);
            ps.setString(3, answer);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // ===== DELETE ACCOUNT =====
    public boolean deleteUser(String username) {

        String sql = "DELETE FROM users WHERE username=?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, username);
            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
