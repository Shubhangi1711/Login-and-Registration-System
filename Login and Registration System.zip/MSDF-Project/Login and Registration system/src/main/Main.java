package main;

import java.util.Scanner;
import service.UserService;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        UserService service = new UserService();

        while (true) {
            System.out.println("\n===== MENU =====");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Forgot Password");
            System.out.println("4. Delete Account");
            System.out.println("5. Exit");

            System.out.print("Enter choice: ");
            int choice = sc.nextInt();

            switch (choice) {

                // ===== REGISTER =====
                case 1:
                    System.out.print("Username: ");
                    String ru = sc.next();

                    System.out.print("Password: ");
                    String rp = sc.next();

                    System.out.print("Security Question (e.g., Your favourite color?): ");
                    String sq = sc.next();

                    System.out.print("Security Answer: ");
                    String sa = sc.next();

                    service.registerUser(ru, rp, sq, sa);
                    break;

                // ===== LOGIN =====
                case 2:
                    System.out.print("Username: ");
                    String lu = sc.next();

                    System.out.print("Password: ");
                    String lp = sc.next();

                    service.loginUser(lu, lp);
                    break;

                // ===== FORGOT PASSWORD =====
                case 3:
                    System.out.print("Username: ");
                    String fu = sc.next();

                    System.out.print("Security Answer: ");
                    String fa = sc.next();

                    System.out.print("New Password: ");
                    String np = sc.next();

                    service.forgotPassword(fu, fa, np);
                    break;

                // ===== DELETE ACCOUNT =====
                case 4:
                    System.out.print("Enter username to delete: ");
                    String du = sc.next();

                    System.out.print("Are you sure you want to delete your account? (y/n): ");
                    String dconfirm = sc.next();

                    if (dconfirm.equalsIgnoreCase("y")) {
                        service.deleteAccount(du);
                    } else {
                        System.out.println("Account deletion cancelled.");
                    }
                    break;

                // ===== EXIT =====
                case 5:
                    System.out.print("Are you sure you want to exit? (y/n): ");
                    String confirm = sc.next();

                    if (confirm.equalsIgnoreCase("y")) {
                        sc.close();
                        System.exit(0);
                    }
                    break;

                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
}
